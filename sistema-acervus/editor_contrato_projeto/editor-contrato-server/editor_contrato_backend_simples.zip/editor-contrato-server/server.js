
const express = require('express');
const multer = require('multer');
const mammoth = require('mammoth');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const port = 3000;
app.use(cors());
const upload = multer({ dest: 'uploads/' });

// Função simples para transformar HTML em Delta com parágrafos
function htmlToSimpleDelta(html) {
  const textOnly = html.replace(/<[^>]+>/g, '');
  const lines = textOnly.split('\n').filter(l => l.trim() !== '');
  const ops = lines.map(l => ({ insert: l.trim() + '\n' }));
  return { ops };
}

app.post('/upload', upload.single('arquivo'), async (req, res) => {
  if (!req.file) return res.status(400).json({ erro: 'Nenhum arquivo enviado.' });

  try {
    const filePath = path.resolve(req.file.path);
    const result = await mammoth.convertToHtml({ path: filePath });
    fs.unlinkSync(filePath);

    const html = result.value;
    const delta = htmlToSimpleDelta(html);

    res.json({ delta });
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro ao converter o arquivo.' });
  }
});

app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
